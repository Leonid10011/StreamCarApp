module.exports = {
  apps: [
    {
      name: 'streamCarBackendReal',
      script: './server.js',
      env: {
        DB_URI:
          'mongodb+srv://leonidbudkov:dWyinmATfRRWUtgo@cluster0.wexpcoy.mongodb.net/streamCar?retryWrites=true&w=majority&appName=Cluster0',
      },
    },
  ],
};
