const QuizMain = () => {};

export default QuizMain;
