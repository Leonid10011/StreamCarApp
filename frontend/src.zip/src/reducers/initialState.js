export const initialState = {
    questionsGeneral: [],
    questionsEstimate: [],
    questionsPrivate: [],
    imagesGuess: [],
    videosZoom:[]
}