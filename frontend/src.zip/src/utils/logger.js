// utils/logger.js

import log from 'loglevel';

log.setLevel('info');

export default log;
