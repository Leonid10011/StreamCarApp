import QuizMenu from "features/QuizModule/components/QuizMenu/QuizMenu";

const QuizPage = () => {
  return <QuizMenu />;
};

export default QuizPage;
