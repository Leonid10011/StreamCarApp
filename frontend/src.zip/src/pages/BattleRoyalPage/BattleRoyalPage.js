import BattleRoyalModule from "features/QuizModule/components/CategoryModules/BattleRoyalModule/BattleRoyalModule";

const BattleRoyalPage = () => {
  return <BattleRoyalModule />;
};

export default BattleRoyalPage;
